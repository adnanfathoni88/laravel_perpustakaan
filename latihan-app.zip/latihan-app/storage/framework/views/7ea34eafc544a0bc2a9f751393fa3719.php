<?php $__env->startSection('title', 'Daftar Rak Buku'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Apakah Anda akan menghapus data ini?</h2>
    <?php if(isset($rak)): ?>
        <table>
            <tr>
                <td>ID</td>
                <td>:</td>
                <td><?php echo e($rak->id); ?></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><?php echo e($rak->nama); ?></td>
            </tr>
            <tr>
                <td>Lokasi</td>
                <td>:</td>
                <td><?php echo e($rak->lokasi); ?></td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td><?php echo e($rak->keterangan); ?></td>
            </tr>
        </table>
    <?php endif; ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Hapus" />&nbsp;
        <div class="send_bt">
            <a href="<?php echo e(url('/rak_buku')); ?>">Kembali</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\21.01.4707\21.01.4707\latihan-app\resources\views/rak_buku/destroy.blade.php ENDPATH**/ ?>