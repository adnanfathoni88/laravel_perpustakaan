@extends('layouts.app')
@section('title', 'Daftar Rak Buku')
@section('content')
    <h2>{{ $store }} Data Rak Buku</h2>
    <form method="POST" action="{{$action}}">
        @csrf
        @if (strtolower($store) == 'ubah')
            @method('PUT')
        @endif
        <div class="container">
            <input type="hidden" name="id" value="{{ $rak->id }}" />
            <input type="text" class="mail_text" name="nama" placeholder="Nama Rak" value="{{ $rak->nama }}" /><br>
            @error('nama')
            <p>{{ $message }}</p>
            @enderror
            <input type="text" class="mail_text" name="lokasi" placeholder="Lokasi" value="{{ $rak->lokasi }}" /><br>
            @error('lokasi')
            <p>{{ $message }}</p>
            @enderror
            <input type="text" class="mail_text" name="keterangan" placeholder="keterangan" value="{{ $rak->keterangan }}" />
            @error('keterangan')
            <p>{{ $message }}</p>
            @enderror
        </div>
        <div class="button">
            <input type="submit" value="{{ $store }}" class="btn btn-primary mt-4 "/>
            <a href="{{ url('/rak_buku') }}" class="btn btn-danger mt-4">Kembali</a>
        </div>
    </form>
@endsection
