<h2>Daftar Buku</h2>
<h3><?php echo e($sub_judul); ?></h3>

<p>Perintah Kondisional</p>
<?php if($poin > 80 && $poin <= 100): ?>
    Rating A<br>
<?php elseif($poin > 60 && $poin <= 80): ?>
    Rating B<br>
<?php elseif($poin > 40 && $poin <= 60): ?>
    Rating C<br>
<?php elseif($poin > 20 && $poin <= 40): ?>
    Rating D<br>
<?php elseif($poin >= 0 && $poin <= 20): ?>
    Rating E<br>
<?php else: ?>
    Salah nilai<br>
<?php endif; ?>

<p>Perintah Switch</p>
<?php switch($flag):
    case (1): ?>
        Jenis Pemrograman<br />
    <?php break; ?>

    <?php case (2): ?>
        Jenis Struktur Data<br />
    <?php break; ?>

    <?php case (3): ?>
        Jenis Basis Data<br />
    <?php break; ?>

    <?php default: ?>
        Bukan buku komputer<br />
<?php endswitch; ?>

<p>Perintah Perulangan</p>
<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($b); ?><br />
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\21.01.4707\21.01.4707\latihan-app\resources\views/buku/list.blade.php ENDPATH**/ ?>