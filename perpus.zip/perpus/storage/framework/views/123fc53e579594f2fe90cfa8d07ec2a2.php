<?php $__env->startSection('title', 'Daftar Rak Buku'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        table{
            width: 100%;
        }
    </style>
    <h2>Daftar Rak Buku</h2>
    <div>
        <div class="">
            <a href="<?php echo e(url('rak_buku/create')); ?>" class="btn btn-primary">Tambah</a>
        </div>
        <?php if(session('pesan')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('pesan')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('hapus')): ?>
        <div class="alert alert-danger mt-3">
            <?php echo e(session('hapus')); ?>

        </div>
        <?php endif; ?>
    </div>
    <table class="table table-bordered table-striped mt-3">
        <tr class="table-primary">
            <th>No.</th>
            <th>ID</th>
            <th>Nama Rak</th>
            <th>Lokasi</th>
            <th>Keterangan</th>
            <th>Aksi</th>
        </tr>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($r->id); ?></td>
                <td><?php echo e($r->nama); ?></td>
                <td><?php echo e($r->lokasi); ?></td>
                <td><?php echo e($r->keterangan); ?></td>
                <td>
                    <a href="rak_buku/<?php echo e($r->id); ?>/edit" class="btn btn-warning">Edit</a>
                    <a href="rak_buku/<?php echo e($r->id); ?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\21.01.4707\21.01.4707\latihan-app\resources\views/rak_buku/index.blade.php ENDPATH**/ ?>